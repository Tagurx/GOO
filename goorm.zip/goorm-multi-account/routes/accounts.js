import express from 'express';
import * as accountController from '../controllers/accounts.js';

const router  = express.Router(); 

// Account routes
router.route('/accounts').get(accountController.all);
router.route('/accounts/create').post(accountController.create);
router.route('/accounts/:uid').get(accountController.show);

export default router;