import { createAccount, getAccounts, generateAccount, getAccount, openAccount, updateAccount } from "../utils/account.js";

export const create = async (req, res, next) => {
  try {
    generateAccount((data) => {
      createAccount(data);
    });
    res.json({ message: 'success', status: true })
  } catch (error) {
    res.status(500).json({ message: error?.message, status: false })
  }
};

export const all = async (req, res, next) => {
  try {
    const data = await getAccounts();
    res.json({ data, message: 'success', status: true })
  } catch (error) {
    res.status(500).json({ data: null, message: error?.message, status: false })
  }
};


export const show = async (req, res, next) => {
  try {
    const uid = req.params.uid
    const account = await getAccount(uid);
    delete(account['_id']);

    account['status'] = true;
    await updateAccount(account);

    const close = async () => {
      account['status'] = false;
      await updateAccount(account);
    }

    openAccount(account, close);

    res.json({ data: account, message: 'success', status: true })
  } catch (error) {
    res.status(500).json({ data: null, message: error.message, status: false })
  }
};
