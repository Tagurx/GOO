import express from 'express';
import path from 'path';
import router from './routes/accounts.js';
import config from './config.js';

const app = express ();
app.use(express.json());

const PORT = config.port;

app.get("/", (request, response) => {
  response.sendFile(path.join(process.cwd(), 'index.html'));
});

app.use('/api/v1', router);

app.listen(PORT, () => {
  console.log("Server Listening on PORT:", PORT);
});