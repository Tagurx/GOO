export default {
  "port": 3000
}