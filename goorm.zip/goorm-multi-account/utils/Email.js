import { parse } from 'node-html-parser';
import UserAgent from 'user-agents';
import chromePaths from 'chrome-paths';
import puppeteer from 'puppeteer-core';

class Email {
  browser = null;
  page = null;
  email = null;

  async getBrowser() {
    if (this.browser) return;
    this.browser = await puppeteer.launch({
      headless: true,
      executablePath: "/usr/bin/google-chrome",
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--ignore-certificate-errors',
        '--ignore-certificate-errors-spki-list',
        '--disable-web-security',
      ],
      ignoreHTTPSErrors: true,
    });
  }

  async getMail() {
    await this.getBrowser();
    const userAgent = new UserAgent({ deviceCategory: 'desktop' });
    const page = await this.browser.newPage();
    await page.setUserAgent(userAgent.toString());
    await page.setViewport({ width: 1440, height: 600 });
    await page.goto("https://pleasenospam.email/", { waitUntil: ['load', 'domcontentloaded'] });
    const email = await page.evaluate(() => document.querySelector('[data-default]').getAttribute('data-default'));

    this.page = page;
    this.email = email;

    return email;
  }

  async getActiveLink() {
    await this.getBrowser();
    await this.page.waitForSelector('.table-responsive-md .table tbody tr', { timeout: 0 });
    const html = await this.page.evaluate(async () => {
      const el = document.querySelector('.table-responsive-md tbody tr.body');
      const id = el?.getAttribute('data-id');
      return fetch(`https://pleasenospam.email/${id}.html`).then(res => res.text());
    })
    const root = parse(html);
    const link = root.querySelector('div > div:nth-child(2) a')?.getAttribute('href');
    await this.page.close();
    await this.browser.close();
    return link;
  }
}

export default Email;