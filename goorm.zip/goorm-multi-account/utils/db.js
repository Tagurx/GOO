// import { faker } from '@faker-js/faker';
// import { MongoClient, ServerApiVersion } from 'mongodb' ;
// import moment from 'moment'

// const DB_USER = 'joniiie1456';
// const DB_PASSWORD = '3tWUuq0w3veGiPfL';
// const uri = `mongodb+srv://${DB_USER}:${DB_PASSWORD}@cluster0.n3jjzou.mongodb.net?retryWrites=true&w=majority&appName=Cluster0`;
// const client = new MongoClient(uri, {
//   serverApi: {
//     version: ServerApiVersion.v1,
//     strict: true,
//     deprecationErrors: true,
//   }
// });

// const db = client.db("browserless");
// const accounts = db.collection("accounts");

// const Account = {
//   create: async (data) => {
//     data['uid'] = faker.string.uuid();
//     data['status'] = true;
//     data['created_at'] = moment().format('YYYY-MM-DD');
//     await accounts.updateOne({ email: data.email }, { "$set": data }, { upsert: true });
//   },
//   update: async (data) => {
//     await accounts.updateOne({ uid: data.uid }, { "$set": data }, { upsert: true });
//   },
//   all: async () => {
//     return await accounts.find({}).toArray();
//   },
//   find: async (uid) => {
//     return await accounts.findOne({ uid });
//   },
// }

// export {
//   db,
//   Account
// };

import { faker } from '@faker-js/faker';
import { Low } from 'lowdb'
import { JSONFile } from 'lowdb/node'
import lodash from 'lodash'
import moment from 'moment';

// Create a class that extends Low and adds lodash chain support
class LowWithLodash extends Low {
  chain = lodash.chain(this).get('data');
}

// Set default data structure
const defaultData = { accounts: [] };

// Initialize the database with Low and lodash chaining
const adapter = new JSONFile('db.json', defaultData);
const db = new LowWithLodash(adapter, defaultData);

// Load the database
await db.read();

// Define the accounts collection using lodash chain
const accounts = db.chain.get('accounts');

// Account operations using lowdb and lodash chaining
const Account = {
  create: async (data) => {
    data['uid'] = faker.string.uuid();
    data['status'] = true;
    data['created_at'] = moment().format('YYYY-MM-DD');

    // Check if account with the same email already exists
    const existingAccount = accounts.find({ email: data.email }).value();
    if (existingAccount) {
      // Update existing account
      accounts.find({ email: data.email }).assign(data).value();
    } else {
      // Add new account
      accounts.push(data).value();
    }

    await db.write();
  },
  update: async (data) => {
    const accountToUpdate = accounts.find({ uid: data.uid }).value();
    if (accountToUpdate) {
      // Update the existing account
      accounts.find({ uid: data.uid }).assign(data).value();
    } else {
      throw new Error("Account not found");
    }

    await db.write();
  },
  all: async () => {
    return accounts.value();
  },
  find: async (uid) => {
    return accounts.find({ uid }).value();
  },
};

export {
  db,
  Account
};
