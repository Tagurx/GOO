import UserAgent from 'user-agents';
import { faker } from '@faker-js/faker';
import { Account } from './db.js';
import chromePaths from 'chrome-paths';
import PuppeteerExtra from 'puppeteer-extra';
import Stealth from 'puppeteer-extra-plugin-stealth';
import Email from "./Email.js";
import lodash from "lodash";
import fs from 'fs';
import path from 'path';
import pluginProxy from 'puppeteer-extra-plugin-proxy'

PuppeteerExtra.use(Stealth());

const getProxy = () => {
  const txt = fs.readFileSync(path.join(process.cwd(), '/utils/proxy.txt'))
  const proxies = txt
    .toString()
    .trim()
    .split('\n')
    .filter(Boolean)
    .map((s) => {
      let [host, port, user, pass] = s.trim().split(':');
      return {
        host,
        port,
        "proxy_user": user,
        "proxy_password": pass
      }
    });

  return lodash.sample(proxies)
}

export const generateAccount = async (cb) => new Promise(async (resolve, reject) => {
  let browser = null;
  const userAgent = new UserAgent({ deviceCategory: 'desktop' });
  
  const proxy = getProxy();
  PuppeteerExtra.use(pluginProxy({
    address: proxy.host,
    port: proxy.port,
    credentials: {
      username: proxy.proxy_user,
      password: proxy.proxy_password,
    }
  }));

  // PuppeteerExtra.use(pluginProxy({
  //   address: 'p.webshare.io',
  //   port: 80,
  //   credentials: {
  //     username: 'bactrvjg-rotate',
  //     password: '0rf81r1bbnxb',
  //   }
  // }));

  try {
    // Launch a headless browser
    browser = await PuppeteerExtra.launch({
      headless: false,
      executablePath: "/usr/bin/google-chrome",
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--ignore-certificate-errors',
        '--ignore-certificate-errors-spki-list',
        '--disable-web-security',
        // `--proxy-server=${proxy.proxy_server}`
      ],
      ignoreHTTPSErrors: true,
    });

    // Create a new page
    const page = await browser.newPage();
    await page.setUserAgent(userAgent.toString());
    await page.setViewport({ width: 1440, height: 600 });
    await page.goto("https://accounts.goorm.io/signup", { timeout: 0 });

    // get mail
    const account = new Email();
    const email = await account.getMail();
    const password = faker.internet.password() + '9..';
    const name = faker.person.fullName();
    const data = { email, password, name };

    console.log(`New Account: ${email} - ${password} - ${name}`);

    const inputMail = await page.$('#emailInput');
    const inputPassword = await page.$('#passwordInput');
    const inputPasswordConfirm = await page.$('#passwordConfirmInput');
    const inputName = await page.$('#nameInput');
    const verifyButton = await page.$('#emailInput + button');

    await inputMail.type(email);
    await inputPassword.type(password);
    await inputPasswordConfirm.type(password);
    await inputName.type(name);
    setTimeout(async () => await verifyButton.click(), 500);

    // Activate
    const link = await account.getActiveLink();
    const page2 = await browser.newPage();
    await page2.goto(link, { waitUntil: 'domcontentloaded' });
    await page2.close();
    data['link'] = link;

    page.on("framenavigated", async (frame) => {
      const url = frame.url(); // the new url
      if (url.startsWith('https://accounts.goorm.io')) {
        cb(data)
        resolve(data);
        page.goto('https://ide.goorm.io/my/dashboard', { timeout: 0 });
      }
    });
  } catch (error) {
    console.log(error);
    await browser.close();
    resolve(null);
  }
})

export const openAccount = async (account, close) => {
  let browser = null;
  const userAgent = new UserAgent({ deviceCategory: 'desktop' });
  const proxy = getProxy();
  PuppeteerExtra.use(pluginProxy({
    address: proxy.host,
    port: proxy.port,
    credentials: {
      username: proxy.proxy_user,
      password: proxy.proxy_password,
    }
  }));

  try {
    // Launch a headless browser
    browser = await PuppeteerExtra.launch({
      executablePath: "/usr/bin/google-chrome",
      headless: false,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--ignore-certificate-errors',
        '--ignore-certificate-errors-spki-list',
      ],
      ignoreHTTPSErrors: true,
    });

    // Create a new page
    const page = await browser.newPage();
    await page.setUserAgent(userAgent.toString());
    await page.setViewport({ width: 1440, height: 660 });
    await page.goto("https://accounts.goorm.io/login?keep_login=true", { timeout: 0 });
    await page.waitForSelector('#emailInput');

    const inputMail = await page.$('#emailInput');
    const inputPassword = await page.$('#passwordInput');
    const submitButton = await page.$('#app > section > div > button');
    await inputMail.type(account.email);
    await inputPassword.type(account.password);
    setTimeout(async () => await submitButton.click(), 800);

    // Go to dashboard
    await page.waitForNavigation({ timeout: 0 });
    await page.goto('https://ide.goorm.io/my/dashboard', { timeout: 0 });

    browser.on('disconnected', () => {
      close();
    });
  } catch (error) {
    console.log(error);
    await browser?.close();
    close();
  }
}

export const createAccount = async (data) => {
  if (!data) return;

  return await Account.create(data);
}

export const updateAccount = async (data) => {
  return await Account.update(data);
}

export const getAccount = async (uid) => {
  return await Account.find(uid);
}

export const getAccounts = async () => {
  return await Account.all();
}
