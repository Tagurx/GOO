npx esbuild index.js  --bundle --outfile=build.cjs --format=cjs --platform=node
npx esbuild index.js --bundle --outfile=build.esm --format=esm --platform=node --target=node18

npx pkg build.cjs -c package.json
npx pkg build.esm -c package.json

